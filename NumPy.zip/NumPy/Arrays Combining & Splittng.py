a = [3,40,50]
b= [5,5,3]
print(a+b)
print(type(a+b))

import numpy as np

#Concatenate
arr1 = np.array([[30,40],[20,50]])
arr2 = np.array([[5,5],[2,3]])
print(np.concatenate([arr1,arr2]))

print(np.concatenate([arr1,arr2],axis=1))
print(np.hstack([arr1,arr2]))       #horizontal concatenation
print(np.vstack([arr1,arr2]))       #vertical concatenation

# Splitting

a = np.array([20,40,30,40,10,20])
b = (np.array_split(a,4))
print(b)