import numpy as np
import statistics as sts
baked_food = [200,150,150,130,200,220,170,188]

a = np.array(baked_food)
print(np.mean(baked_food))  #sum of all the values/number of values
print(np.median(baked_food))   #central value after sorting
print(sts.mode(baked_food))   #mode
print(np.std(baked_food))    #standard deviation
print(np.var(baked_food))    #variance

# -1 represents inversely proportional relationship
#  1 represents proportional relationship
#  0 means no relationship
tabacco_consumption = [30, 50, 10,30,50,40]
deaths = [100,120,70,100,120,112]
print(np.corrcoef([tabacco_consumption,deaths]))   #correlation of coefficient


price = [300,100,350,150,200]
sales = [10,20,7,17,3]

print(np.corrcoef([price,sales]))