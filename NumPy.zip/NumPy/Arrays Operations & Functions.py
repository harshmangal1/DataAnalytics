# Functions
"""
g=a-b
np.subtract (a, b)
b+an
p.add (b, a)
a/ b
np.divide(a,b)
a*b
np.multiply (a, b)
np.exp(b)
np.sqrt(b)
np.pow(a)
"""
import numpy as np

arr1= np.array([30,40,60,20,10])
arr2 = np.array([30, 20,10,20,20])
print(arr1+arr2)
print(np.add(arr1, arr2))

arr1= np.array([[30,40],[20,10]])
arr2 = np.array([[30, 20],[10,20]])
print(arr1+arr2)
print(np.add(arr1, arr2))


print(arr1-arr2)
print(np.subtract(arr1,arr2))

print(arr1*arr2)
print(np.multiply(arr1, arr2))

print(arr1/arr2)
print(np.divide(arr1, arr2))

arr1= np.array([3,4,6,2,1])
arr2  = np.array([2])
print(np.power(arr1,arr2))

arr1 = np.array([ 9, 16 ,36 , 4 ,1])
print(np.sqrt(arr1))