# NumPy
"""
•NumPy is the short form of Numerical Python.

•In 2005, Travis Oliphant created NumPy package.

•NumPy is a package that defines a multi-dimensional array object. and associates fast math functions that operate on

It also has functions for working in domain of linear Algebra, Fourier Transformation and Matrices.

In simple words, it is the fundamental package for Scientific computing in Python.
"""

# Advantages of Using Arrays:
"""
1. NumPy uses much less memory to store data.
2. NumPy makes it extremely easy to perform mathematical operations on it.
3. Used for the creation of n-dimensional arrays.
4. Finding elements in NumPy array is easy.
5. A List cannot directly handle Mathematical Operations, while Array can.
6. An Array consumes less memory than a List.
7. Using an Array is faster than List.
8. A List store different datatypes, while you can't do that in an Array."""

import numpy as np
a = np.array([20,30,40])
b = np.array([60,70,80])
print(a)
print(b)
print(a+b)
print(a*b)




l1 = [20,30,40]
l2 = [50,60,70]
l3 = 5
print(l1+l2)
print(l1*l3)