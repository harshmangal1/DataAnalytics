# Arrays:
"""
1. An array is defined as a collection of items that are stored at
contiguous memory locations.

2. It is a container which can hold a fixed number of items, and
these items should be of the same type.

3. A combination of arrays saves a lot of time. The array can reduce
the overall size of the code.
"""

# Advantages of Using Arrays:
"""
1. NumPy uses much less memory to store data.
2. NumPy makes it extremely easy to perform mathematical
operations on it.
3. Used for the creation of n-dimensional arrays.
4. Finding elements in NumPy array is easy.
"""