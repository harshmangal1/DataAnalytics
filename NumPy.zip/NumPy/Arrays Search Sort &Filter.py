# NumPy - Sort, Filter and Search
import numpy as np

ar = np.array([[3,4,9,2,5],[7,4,9,3,2]])
print(np.sort(ar))

ar = np.array([3,4,1,7,8,0,9,2,5,6])
ss = np.searchsorted(ar,5)
# s = np.where(ar == (int(input("enter any number(0 to 9)", ))))
print(ss)

# filter
arrr = np.array([20,30,40,50])
# fa = [True,False,True,False]
# print(arrr[fa])
fa = arrr>35
print(arrr[fa])