# Functions
"""
* np.append (h,g) - Append items to an array
* np.insert (a,1,5) -Inserts items in an array
* n.delete (a,[1]) - Delete items from an array
"""
import numpy as np
a = np.array([[10,20],[30,40]])
print(np.append(a,[10,90]))

print(np.insert(a, 2,[70,80]))      #array,index,value
print(np.insert(a, 2,[70,80],axis=1))      #array,index,value


print(a)
print(np.delete(a,1))