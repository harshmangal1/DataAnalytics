"""
•A List cannot directly handle Mathematical Operations, while Array can.
•An Array consumes less memory than a List.
•Using an Array is faster than List.
•A List can store different datatypes, while you can't do that in an Array.
•A List is easier to modify since a list store each element individually, it is easier to add and delete an element than an array does.
•In Lists one can have nested data with different size, while you cannot do the same in array.
"""