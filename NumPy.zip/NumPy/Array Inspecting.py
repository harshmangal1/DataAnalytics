# Functions
"""
* A.shape- array dimensions
* len(a) - Length of array
* b.ndim - Number of array dimensions
* e.size - Number of array element
* b.dtype - Data type of array element
* b.astype(int) - Convert on array to a different type

"""
import numpy as np

a = [30,40,20],[30,40,30]
arr = np.array(a)
print(arr)

print(arr.shape)     #rows, columns
print(len(arr))       #number of nested values
print(arr.size)       #number of elements
print(type(arr))      #data type of variable
print(arr.dtype)      #datatype of array
print(arr.astype(float))          #conversion of datatype