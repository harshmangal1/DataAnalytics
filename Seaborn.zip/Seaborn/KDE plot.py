# Kernal Density Estination
import seaborn as sns
import matplotlib.pyplot as plt

data = sns.load_dataset("tips")
print(data)
sns.kdeplot(data=data,x="total_bill",hue="day",multiple="stack",)  #multiply="fill"
# sns.histplot(data=data,x="total_bill")
plt.show()