import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

data = sns.load_dataset('tips')
print(data)
sns.scatterplot(data=data,x="total_bill",y="tip",hue="day",size="size")
plt.show()


import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

data = pd.read_excel("C:/Users/deewa/Desktop/Datasets-main/ESD.xlsx")
# print(data)
sns.scatterplot(data=data,x="Age",y="Annual Salary",size="Bonus %",hue="Department")
plt.legend(bbox_to_anchor = (0.2,0,1.2,1.02))
plt.show()