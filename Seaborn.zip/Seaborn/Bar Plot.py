import seaborn as sns
import matplotlib.pyplot as plt

data = sns.load_dataset("tips")
print(data)
sns.barplot(data=data,x="day",y="tip",estimator="median")
plt.plot()



import seaborn as sns
import matplotlib.pyplot as plt

data = sns.load_dataset("tips")
print(data)
sns.barplot(data=data,x="day",y="tip",hue="sex",palette="Blues",order = ["Sun","Sat","Fri","Thur"],errorbar=("ci",0))
plt.plot()