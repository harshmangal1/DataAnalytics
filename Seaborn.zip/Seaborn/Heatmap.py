import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

data = sns.load_dataset('tips')
gp = data.groupby("day").agg({"tip":"mean"})
sns.heatmap(gp)
plt.show()


import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

data = pd.read_excel("C:/Users/deewa/Desktop/Datasets-main/ESD.xlsx")
gp = data.groupby("Job Title").agg({"Annual Salary":"mean"})
sns.heatmap(gp)
plt.show()