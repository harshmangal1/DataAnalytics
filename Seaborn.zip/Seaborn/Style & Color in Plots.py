import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt

# data = sns.load_dataset("exercise")
# sns.set_style(style="whitegrid")
# # print(data)
# sns.barplot(data=data,x="time",y="pulse")
# plt.show()

# sns.palplot(sns.color_palette())
sns.palplot(sns.color_palette("viridis"))
plt.show()