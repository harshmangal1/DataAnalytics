import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
data = sns.load_dataset("tips")
print(data)
sns.violinplot(data=data,x="tip")
plt.show()


import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

df = pd.read_excel("C:/Users/deewa/Desktop/Datasets-main/ESD.xlsx")
sns.violinplot(data=df,x = "Age",hue="Gender")
