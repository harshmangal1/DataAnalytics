# Data Visualization:
"""
  * Data Visualization is the graphical representation of information and data.
  * In the world of Big data, data visualization tools and technologies are
    essential to analyze massive amounts of information and makes data-driven
    decisions.
"""
# Seaborn:
"""
  * Seaborn is a python data visualization library based on matplotlib. it 
    provides a high-level interface for drawing attractive statistical graphics.
"""