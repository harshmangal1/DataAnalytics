import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt

data = sns.load_dataset("tips")
print(data)

sns.countplot(data=data,x="day")
plt.show()


import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

df = pd.read_excel("C:/Users/deewa/Desktop/Datasets-main/ESD.xlsx")
print(df)

# gp = data.groupby("Job Title").agg({"Annual Salary":"mean"})
sns.countplot(data=df,x = "Department",hue="Gender")
# plt.xlabel(fontsize = 10)
# plt.show()