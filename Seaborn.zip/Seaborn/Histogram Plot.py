import seaborn as sns
import matplotlib.pyplot as plt

data  = sns.load_dataset('tips')
sns.histplot(data,x = "day",hue="sex",kde=True)
plt.show()


import seaborn as sns
import matplotlib.pyplot as plt

data  = sns.load_dataset('titanic')
sns.histplot(data=data,x = "age",hue="who",kde=True,bins=20)
plt.show()
# print(data)