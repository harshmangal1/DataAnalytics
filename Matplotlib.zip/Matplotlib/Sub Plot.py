import matplotlib.pyplot as plt
plt.suptitle("Employees Data")

x = [1,2,3,4,5]
y = [45,34,56,23,45]
plt.subplot(2,3,1)
plt.title("Age")
plt.plot(x,y)
plt.show()

x =[5,6,7,8,9]
y =[67,50,66,56,82]
plt.subplot(2,3,2)
plt.title("heigth")
plt.plot(x,y)
plt.show()

x =[2,4,6,8,10]
y =[57,50,60,55,20]
plt.subplot(2,3,3)
plt.title("Weight")
plt.plot(x,y)
plt.show()

x =[1,3,5,7,9]
y =[67,52,62,50,23]
plt.subplot(2,3,4)
plt.title("blood group")
plt.plot(x,y)

plt.show()