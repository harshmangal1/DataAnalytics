# BoxPlot

import matplotlib.pyplot as plt
l = [25,46,57,25,45,13,29,39,46,99,22,12,14,55,6,46,52,55]
plt.boxplot(l)
plt.show()

"""
* Min (Lower Fence)
* Q1 --> 25% = 25/100*(no if values + 1)
* Median
* Q3 --> 75% = 75/100*(no if values + 1)
* Max (Upper Fence)

Formuls:
   Min/LF = Q1 - 1.5(IQR- Inter Quartile Range)
   Max/UF = Q3 + 1.5(IQR- Inter Quartile Range)

   IQR = Q3 -Q1
   
"""

import matplotlib.pyplot as plt
l = [1,3,4,7,12,2,8,9,24]
l1 = [2,3,4,6,3,5,7,3,6]

plot_values = [l,l1]
plt.boxplot(plot_values)
plt.show()

import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_excel("C:/Users/deewa/Desktop/Datasets-main/ESD.xlsx")
df = pd.DataFrame(data)

plt.boxplot(df["Annual Salary"])
plt.show()
plt.savefig("boxplot.png")