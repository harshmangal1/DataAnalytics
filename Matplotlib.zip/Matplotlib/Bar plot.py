import matplotlib.pyplot as plt

y = [98,67,88,95,88]
x = ["Part1","Part2","Part3","Part4","Part5"]
colors = ["red","yellow","green","blue","orange"]
plt.bar(x,y,color = colors,edgecolor = "black")
plt.xlabel("Parts of Harry Potter",fontsize = 17)
plt.ylabel("Popularity",fontsize = 17)
plt.title("Popularity of Different parts of Harry Potter",fontsize=20)
# plt.show()

import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_excel("C:/Users/deewa/Desktop/Datasets-main/expense3.xlsx")
df = pd.DataFrame(data)
print(df)
grouped_by = df.groupby("Payment Mode")["Amount"].sum()
plt.bar(grouped_by.index,grouped_by.values)
plt.show()
plt.savefig("bar1.png",facecolor="black")
print(grouped_by)