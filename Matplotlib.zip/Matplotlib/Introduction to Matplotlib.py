# Data Visualization:
"""
Data visualization is the graphical representation of information
and data.

In the world of Big Data, data visualization tools and
technologies are essential to analyze massive amounts of
information and make data-driven decisions.
"""

# Matplotlib
"""
* Matplotlib is a low-level graph plotting library in python that serves as a visualization utility.

* Matplotlib was created by John D. Hunter.

* Matplotlib is open-source and we can use it freely."""

# Matplotlib charts:
"""
Scatter plot
Step plot
Bar chart
Fill Between
Time series
Box plot
Histogram"""