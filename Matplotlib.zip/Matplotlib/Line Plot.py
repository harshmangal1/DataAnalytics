import matplotlib.pyplot as plt

x = ["day1","day2","day3","day4","day5"]
y = [300,420,250,230,400]
y1= [500,450,300,250,320]
plt.plot(x,y,marker = "o",ls = "-",color="green",label="week1",alpha=0.5)
plt.plot(x,y1,marker = "o",ls = ":",color="red",label="week2")
plt.legend()
plt.show()


import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_excel("C:/Users/deewa/Desktop/Datasets-main/expense3.xlsx")
df = pd.DataFrame(data)
grouped_by = df.groupby("Category")["Amount"].sum()
print(grouped_by)
plt.plot(grouped_by.index,grouped_by.values)
print(df)
plt.show()