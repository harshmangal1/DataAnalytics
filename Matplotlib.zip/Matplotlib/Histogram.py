import matplotlib.pyplot as plt

x = [30,40,68,27,47,59,47,88,44,23,44,66,66,33,5,2,5,50,12,17,16]

plt.hist(x,bins = 15,edgecolor = "black",color="pink")
plt.show()

import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_excel("C:/Users/deewa/Desktop/Datasets-main/ESD.xlsx")
df = pd.DataFrame(data)
print(df)

plt.hist(df["Age"],bins = 20,edgecolor="black")
plt.show()