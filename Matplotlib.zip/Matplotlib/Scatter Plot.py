import matplotlib.pyplot as plt
import numpy as np

x = np.random.randint(1,10,50)
y = np.random.randint(10,100,50)
color = np.random.randint(10,100,50)
size = np.random.randint(10,100,50)

plt.scatter(x,y,marker = "*",cmap = "viridis",c = color,s = size)
plt.colorbar()
plt.show()


import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

data = pd.read_excel("C:/Users/deewa/Desktop/Datasets-main/ESD.xlsx")
df = pd.DataFrame(data)
print(df)
plt.scatter(df["Annual Salary"],df["EEID"],s = df["Age"])
plt.show()