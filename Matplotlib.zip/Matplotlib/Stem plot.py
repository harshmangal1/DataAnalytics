import matplotlib.pyplot as plt
x = [10,40,20,40,20,40,20,40,60,70,50,40]

plt.stem(x,linefmt="--",markerfmt="D",orientation="horizontal")
plt.show()



import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_excel("C:/Users/deewa/Desktop/Datasets-main/ESD.xlsx")
df = pd.DataFrame(data)
df2 = (df.head(50))
plt.stem(df2["Age"])
plt.plot(df2["Age"])
plt.show()