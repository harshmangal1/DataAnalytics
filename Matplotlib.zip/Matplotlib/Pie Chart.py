import matplotlib.pyplot as plt
brands = ["Oneplus","Apple","Samsung","Nokia","Redmi"]
x =[22,35,30,3,10]
c = ["orange","red","blue","magenta","green"]
ex=[0,0,0,0,0.05]

plt.pie(x,labels = brands,colors=c,explode=ex,shadow = True,autopct="%.2f",startangle=90)
plt.show()


import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_excel("C:/Users/deewa/Desktop/Datasets-main/expense3.xlsx")
df = pd.DataFrame(data)
grouped_by = df.groupby("Payment Mode")["Amount"].sum()
print(grouped_by)
plt.pie(grouped_by.values,labels = grouped_by.index,autopct = "%.2f")
plt.show()
plt.savefig("pieChart.png")
print(df)