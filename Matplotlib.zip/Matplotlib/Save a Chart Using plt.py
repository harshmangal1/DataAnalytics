import matplotlib.pyplot as plt

plt.savefig("bar.png")
