import matplotlib.pyplot as plt

# x =["day1","day2","day3","day4","day5"]
# y = [30,40,25,30,40]

# plt.step(x,y,where="pre")
# plt.show()

import pandas as pd
data = pd.read_excel("C:/Users/deewa/Desktop/Datasets-main/expense3.xlsx")
df = pd.DataFrame(data)
print(df)

group = df.groupby("Category").agg({"Amount":"sum"})
print(group)
plt.step(group.index,group["Amount"],where="mid",marker="o")
plt.show()