import matplotlib.pyplot as plt
days = [1,2,3,4,5,6,7]
NQP1 = [5,10,30,20,35,60,80]
NQP2 = [10,20,30,25,40,50,90]
NQP3 = [8,30,50,60,70,90,100]

plt.stackplot(days,NQP1,NQP2,NQP3)
plt.show()


import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv("C:/Users/deewa/Desktop/Datasets-main/food_data.csv")
df = pd.DataFrame(data)
print(df)
grouped = df.groupby("Category")["Calories","Protein","Fat"].agg("mean")

plt.stckplot(df["Category"],unique(),grouped["Calories"],grouped["Protein"],grouped["Fat"])
plt.show()