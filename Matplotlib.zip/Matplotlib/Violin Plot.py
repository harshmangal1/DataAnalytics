import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_excel("C:/Users/deewa/Desktop/Datasets-main/ESD.xlsx")
df = pd.DataFrame(data)
# print(df)
plt.violinplot(df["Age"],showmedians=True)
plt.show()

import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_excel("C:/Users/deewa/Desktop/Datasets-main/ESD.xlsx")
df = pd.DataFrame(data)
# print(df)
plt.violinplot(df["Annual Salary"],showmedians=True)
plt.show()

