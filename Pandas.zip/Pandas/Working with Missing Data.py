from traceback import print_tb

import pandas as pd
import numpy as np
data = pd.read_csv("Book1.csv")
print(data)

print(data.isnull().sum())

print(data.replace(np.nan,"hi"))

data["Salary"] = data["Salary"].replace(np.nan,24400)
print(data)
print(data["Salary"].mean())

data = pd.read_csv("Book1.csv")
print(data)

print(data.fillna(method="ffill"))
print(data.fillna(method="bfill"))

