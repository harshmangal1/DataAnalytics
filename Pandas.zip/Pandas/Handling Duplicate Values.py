import pandas as pd

data = pd.read_csv("Book1.csv")
print(data)

print(data["EEID"].duplicated().sum())

print(data.drop_duplicates("EEID"))