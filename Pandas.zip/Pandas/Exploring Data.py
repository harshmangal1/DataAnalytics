import pandas as pd
data = pd.read_excel("Employees.xlsx")
# print(data)
print(data.head(10))
print(data.tail(10))

print(data.info())

print(data.describe())

print(data.isnull().sum())