# Pandas
"""
* Pandas is a Python packages providing fast, flexible, and expressive data
  structures designed to make working with "relational" or "labeled" data both easy
  and intuitive.
* Here are just a few of the things that pandas does well:
it has functions for analyzing, cleaning, and manipulating data.

* The name "Pandas" has a reference to both "Panel Data" and "Python data
  Analysis" and was created by Wes McKinney in 2008.
"""

# Pandas Applications
"""
* Easy handling of missing data.
* Size mutability: columns can be inserted and deleted from DataFrame and
higher dimensional Objects.
* Automatic and explicit data alignment: Objects can be explicitly aligned to a set
of labels, or the user can simply ignore the labels and let Series, DataFrame etc.

* Automatically align the data for you in computations.
* Powerful, flexible group by functionality.
* Intelligent label-based slicing, fancy Indexing, and sub setting of large data sets.
* Intuitive merging and joining data sets.
* Flexible reshaping and pivoting of data sets. 
"""

# Data Structures
"""
The best way to think about the pandas data structures in as flexible
containers for lower dimensional data. For example, DataFrame is a
container for Series, and Series is a container for scalars. We would
like to be able to insert and remove objects from these containers in a
dictionary-like fashion."""

# Series in Pandas:
"""
Pandas Series is a one-dimensional labeled array capable of holding
dat of any typ(integer, string, float,python object, etc.). This axis
labels are collectively called index. Pandas Series is nothing but a
column in an excel sheet.
The object supports both integer and label-based indexing and
provides a host of methods for performing operations involving the index."""

# DataFrames:
"""
Pandas DataFrame is two-dimensional size-mutable, potentially
heterogeneous tabular data structure with labeled axes (rows and
columns). A Data frame is a two-dimensional data structure, i.e., data
is aligned in a tabular fashion in rows and columns. Pandas DataFrame
consists of three principal components, the data, rows, and columns."""

