import pandas as pd

# df= pd.read_excel("Employees.xlsx")
#
# df.loc[(df["Bonus %"] == 0),"GetBonus"] ="no bonus"
# df.loc[(df["Bonus %"] == 0),"GetBonus"] ="Bonus"
# print(df.columns())

data = pd.read_excel("practice1.xlsx")
print(data)

# data ["full Name"]= data["First name"].str.capitalize() + " "+data["Last name"].str.capitalize()
# print(data)
data["Bonus"] = (data["Salary"]/100)*20
print(data)

data = {"Months":["January","February","March","April","May","June","July","Aug"]}
a = pd.DataFrame(data)
print(a)

def extract(value):
    return value[0:3]
a["Short_months"]=a["Months"].map(extract)
print(a)