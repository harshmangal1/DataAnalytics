import pandas as pd

data = pd.read_excel("Employees.xlsx")
print(data)

gp = data.groupby(["Department","Gender"]).agg({"No":"count"})
print(gp)

# gp1 = data.groupby("Country").agg({"Start Date":"mean"})
# print(gp1)

# gp1 = data.groupby("Country").agg({"Annual Salary":"mean"})
# print(gp1)

# gp1 = data.groupby("Country").agg({"Annual Salary":"max"})
# print(gp1)

gp1 = data.groupby(["Country","Gender"]).agg({"Annual Salary":"max","Years":"max"})
print(gp1)